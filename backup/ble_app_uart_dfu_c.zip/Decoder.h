#include <stdint.h>
#include <string.h>


#define SPI_CODE		0
#define UART_CODE		1

#define SEC_BYTE_NUM	61


void Decode(uint8_t* data);
void Encode (uint8_t* data);
void Encrypt_on(void);
void Encrypt_off(void);
