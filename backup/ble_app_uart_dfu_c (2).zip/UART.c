//////////////////////////////////////////////////////////////
//						IR COMMAND							//
//////////////////////////////////////////////////////////////
#include <stdint.h>
#include <string.h>
#include "Structures.h"
#include "app_uart.h"
#include "nrf_drv_timer.h"
#include "bsp.h"
//#include "nrf_drv_gpiote.h"
#include "nrf_gpio.h"

#include "uart.h"
//-------------------------------------------------------------
void uart_stop(void);
//-------------------------------------------------------------
#define USED_PWM(idx) (1UL << idx)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#define APP_TIMER_PRESCALER             0                                           /**< Value of the RTC1 PRESCALER register. */
#define UART_BUFF_SIZE					128

extern FLAGSmy_t _flags;

statRxDT_t statRxDTbits;
statTxDT_t statTxDTbits;
uint8_t RCREG, TXREG;
uint8_t uart_rx_buff[UART_BUFF_SIZE];
uint8_t uart_tx_buff[UART_BUFF_SIZE];
uint8_t idx = 0;
							
uint8_t countStartRx =0;
uint8_t countStringRx =0;
uint8_t countRxBuf =0;
uint8_t countStartTx =0;
uint8_t countStringTx =0;
uint8_t countTxBuf =0;
						

//-------------------------------------------------------------
void uart_tx_buff_clear(void)
{
	memset(uart_tx_buff, 0x00, sizeof(uart_tx_buff));
}
//-------------------------------------------------------------
void* GetUART_xor(void)
{
	return &uart_rx_buff[0] + DONGLE_XOR_IDX;
}
//-------------------------------------------------------------
void* GetUART_dat(void)
{
	return &uart_rx_buff[0] + DONGLE_DATA_IDX;
}
//-------------------------------------------------------------
void* GetUART_com(void)
{
	return &uart_rx_buff[0] + DONGLE_COMMAND_IDX;
}
//-------------------------------------------------------------
void* GetUART_len(void)
{
	return &uart_rx_buff[0] + DONGLE_LEN_IDX;
}
//-------------------------------------------------------------
void* GetUART_addr(void)
{
	return &uart_rx_buff[0] + UART_ADDR_IDX;
}
//-------------------------------------------------------------
void SetUART_TX(void* data)
{
	uart_tx_buff_clear();
	memcpy(uart_tx_buff, data, UART_BUFF_SIZE);
}
//-------------------------------------------------------------
void SetUART_control_TX(uint8_t index, void* data, uint8_t len)
{
	if (index >= UART_BUFF_SIZE || len > (UART_BUFF_SIZE + index))
		return;
	
	memcpy(&uart_tx_buff[index], data, len);
}
//-------------------------------------------------------------
void* GetUART_TX(void)
{
	return uart_tx_buff;
}
//-------------------------------------------------------------
void* GetUART_RX(void)
{
	return uart_rx_buff;
}
//-------------------------------------------------------------
void send_message(void)
{
	statTxDTbits.Bits.start_transmitter = 1;
	UART_TX_F = 1;
}
//-------------------------------------------------------------
void reset_buff(void)
{
	countStringRx = 0;	
	countRxBuf = 0;
	countStartRx = 0;
	statRxDTbits.Full = 0;
}
//-------------------------------------------------------------
void tx_message(void)
{
	#define MAX_CNT		200//200//2000
	uint32_t i;
	
	if (statTxDTbits.Bits.start_transmitter)
	{
		if (!statTxDTbits.Bits.transmit_55_complete) 
		{
			if (countStartTx < 9)
			{	
				countStartTx ++;
				TXREG = 0x55;                
				//while (app_uart_put(TXREG) != NRF_SUCCESS);
				app_uart_put(TXREG);
				for	(i=0; i<MAX_CNT; i++) {;}
			}
			else
			{
				statTxDTbits.Bits.transmit_55_complete = 1;
				countStringTx =0;
				countTxBuf = 0;
				countStartTx = 0;
				TXREG = 0xAA; 
				//while (app_uart_put(TXREG) != NRF_SUCCESS);
				app_uart_put(TXREG);
				for	(i=0; i<MAX_CNT; i++) {;}
			}
		}
		else
		{
			if (countStringTx < 8)
			{
				TXREG = uart_tx_buff[countTxBuf];
				countTxBuf ++;
				countStringTx ++; 
				//while (app_uart_put(TXREG) != NRF_SUCCESS);
				app_uart_put(TXREG);
				for	(i=0; i<MAX_CNT; i++) {;}
			}
			else
			{
				TXREG = 0xAA;
				countStringTx =0;
				if (countTxBuf == UART_BUFF_SIZE)
					statTxDTbits.Bits.transmit_complete = 1;  
				//while (app_uart_put(TXREG) != NRF_SUCCESS);
				app_uart_put(TXREG);
				for	(i=0; i<MAX_CNT; i++) {;}
			}
		}
	}
	if (statTxDTbits.Bits.transmit_complete)
	{
		countStringTx =0;
		countTxBuf = 0;
		countStartTx = 0;
		statTxDTbits.Full = 0;
		UART_TX_F = 0;
		UART_TX_COMPLETE = 1;
	}
}
//-------------------------------------------------------------
void rx_message(void)
{
	uint8_t bufRxUART = 0;
	
	//uart_waiting_timer_restart();
	
	bufRxUART = RCREG;
	if (statRxDTbits.Bits.start_reciver)		// прием данных
	{
		if (countStringRx < 8)		// прием строки
		{
			uart_rx_buff[countRxBuf] = bufRxUART;
			countRxBuf ++;
			countStringRx ++;
		}
		else 
		{
			if (bufRxUART == 0xAA)	// конец строки
			{
				countStringRx = 0;
				if (countRxBuf == UART_BUFF_SIZE)		// конец массива
				{
					countRxBuf = 0;
					countStartRx = 0;
					statRxDTbits.Full = 0;
					statRxDTbits.Bits.data_complete = 1;
					UART_RX_F = 1;
					
					uart_waiting_timer_stop();
				}
			}
			else		// ошибка строки - в конце не 0xAA (сброс массива)
			{
				countStringRx = 0;	
				countRxBuf = 0;
				countStartRx = 0;
				statRxDTbits.Full = 0;
				set_error(UART_ERROR_E1);
			}
		}
	}
	else		// прием 10-байтной строки-маркера 9*0x55+0xAA
	{
		if (statRxDTbits.Bits.char_55_complete)
		{
			if (bufRxUART == 0xAA)	// конец строки-маркера, запуск приема массива
			{
				statRxDTbits.Bits.start_reciver = 1;
				countStringRx = 0;	
				countRxBuf = 0;
			}
			else		// ошибка маркера (сброс массива)
			{
				countStringRx = 0;	
				countRxBuf = 0;
				countStartRx = 0;
				statRxDTbits.Full = 0;
				set_error(UART_ERROR_E1);
			}
		}
		else		// продолжение приема строки-маркера
		{
			if (bufRxUART == 0x55)
			{
				countStartRx ++;
				if (countStartRx == 9)
					statRxDTbits.Bits.char_55_complete = 1;
			} 
			else		// ошибка маркера (сброс массива)
			{
				countStringRx = 0;	
				countRxBuf = 0;
				countStartRx = 0;
				statRxDTbits.Full = 0;
				set_error(UART_ERROR_E2);
			}
		}
	}
}

//-------------------------------------------------------------
/**@brief   Function for handling app_uart events.
 *
 * @details This function will receive a single character from the app_uart module and append it to
 *          a string. The string will be be sent over BLE when the last character received was a
 *          'new line' i.e '\r\n' (hex 0x0D) or if the string has reached a length of
 *          @ref NUS_MAX_DATA_LENGTH.
 */
/**@snippet [Handling the data received over UART] */
void uart_event_handle(app_uart_evt_t * p_event)
{
    uint32_t       err_code;

    switch (p_event->evt_type)
    {		
        case APP_UART_DATA_READY:										// данные приняты UART
			if (app_uart_get(&RCREG) != NRF_SUCCESS) return;		
			rx_message();
			//app_uart_flush();
            break;
		
		case APP_UART_TX_EMPTY:									// данные отправлены UART
			break;

        case APP_UART_COMMUNICATION_ERROR:
//            APP_ERROR_HANDLER(p_event->data.error_communication);
			NRF_UART0->EVENTS_ERROR = 0;
			err_code = NRF_UART0->ERRORSRC;
			NRF_UART0->ERRORSRC = err_code;
            break;

        case APP_UART_FIFO_ERROR:
//            APP_ERROR_HANDLER(p_event->data.error_code);
			NRF_UART0->EVENTS_ERROR = 0;
			err_code = NRF_UART0->ERRORSRC;
			NRF_UART0->ERRORSRC = err_code;
            break;

        default:
            break;
    }
}
/**@snippet [Handling the data received over UART] */


/**@brief  Function for initializing the UART module.
 */
/**@snippet [UART Initialization] */
static void uart_init(void)
{
	uint32_t	err_code;
	uint8_t 	err_cnt = 0;
	
    app_uart_comm_params_t const comm_params =
    {
        .rx_pin_no    = RX_PIN_NUMBER,
        .tx_pin_no    = TX_PIN_NUMBER,
        .rts_pin_no   = RTS_PIN_NUMBER,
        .cts_pin_no   = CTS_PIN_NUMBER,
        .flow_control = APP_UART_FLOW_CONTROL_DISABLED,
        .use_parity   = false,
        .baud_rate    = UART_BAUDRATE_BAUDRATE_Baud9600//UART_BAUDRATE_BAUDRATE_Baud115200//
    };
	
	do
	{
		APP_UART_FIFO_INIT(&comm_params,
						   UART_RX_FIFO_SIZE,
						   UART_TX_FIFO_SIZE,
						   uart_event_handle,
						   APP_IRQ_PRIORITY_LOWEST,
						   err_code);
		err_cnt++;
	}
	while(err_code != NRF_SUCCESS || err_cnt > 100);
	
    APP_ERROR_CHECK(err_code);
	
//	nrf_gpio_cfg_output(TX_PIN_NUMBER);
//	nrf_gpio_cfg_input(RX_PIN_NUMBER, NRF_GPIO_PIN_PULLUP);
}
/**@snippet [UART Initialization] */

void uart_start(void)
{
	app_uart_close();	
	uart_init();
}

void uart_stop(void)
{
	app_uart_flush();
	app_uart_close();
	
	nrf_gpio_cfg_output(RX_PIN_NUMBER);
	nrf_gpio_pin_clear(RX_PIN_NUMBER);
	nrf_gpio_cfg_output(TX_PIN_NUMBER);
	nrf_gpio_pin_clear(TX_PIN_NUMBER);
	
//	nrf_gpio_cfg_input(RX_PIN_NUMBER, NRF_GPIO_PIN_NOPULL);
//	nrf_gpio_cfg_input(TX_PIN_NUMBER, NRF_GPIO_PIN_NOPULL);
}
