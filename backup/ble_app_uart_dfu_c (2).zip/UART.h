
#define UART_TX_FIFO_SIZE                256				/**< UART TX buffer size. */
#define UART_RX_FIFO_SIZE                256				/**< UART RX buffer size. */

//	Baudrate = desired baudrate * 2^32 / 16000000
#define UART_BAUDRATE_BAUDRATE_Baud70887 (0x01225A68UL) /*!< 76800 baud (actual rate: 70887) */

typedef union
{
    uint8_t Full;

    struct
    {
        unsigned start_reciver		: 1;
        unsigned char_55_complete	: 1;
        unsigned data_complete		: 1;
    }Bits;
} statRxDT_t;

typedef union
{
    uint8_t Full;

    struct
    {
        unsigned start_transmitter		: 1;
        unsigned transmit_55_complete	: 1;
        unsigned transmit_complete		: 1;
    }Bits;
} statTxDT_t;


void uart_start(void);
void uart_stop(void);
void reset_buff(void);
void send_message(void);
void rx_message(void);
void tx_message(void);
void* GetUART_RX(void);
void* GetUART_TX(void);
void SetUART_TX(void* data);
void SetUART_control_TX(uint8_t index, void* data, uint8_t len);
void* GetUART_addr(void);
void* GetUART_len(void);
void* GetUART_com(void);
void* GetUART_dat(void);
void* GetUART_xor(void);
void uart_tx_buff_clear(void);
